﻿
namespace Kasir
{
    partial class FormTransaksi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSepatu = new System.Windows.Forms.Button();
            this.btnBrand = new System.Windows.Forms.Button();
            this.btnTipe = new System.Windows.Forms.Button();
            this.btnuser = new System.Windows.Forms.Button();
            this.btnTtlTrans = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 38);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(444, 318);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Transaksi Toko";
            // 
            // btnSepatu
            // 
            this.btnSepatu.Location = new System.Drawing.Point(464, 102);
            this.btnSepatu.Margin = new System.Windows.Forms.Padding(2);
            this.btnSepatu.Name = "btnSepatu";
            this.btnSepatu.Size = new System.Drawing.Size(128, 59);
            this.btnSepatu.TabIndex = 2;
            this.btnSepatu.Text = "Laporan Sepatu Paling Banyak Dijual";
            this.btnSepatu.UseVisualStyleBackColor = true;
            this.btnSepatu.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBrand
            // 
            this.btnBrand.Location = new System.Drawing.Point(464, 166);
            this.btnBrand.Margin = new System.Windows.Forms.Padding(2);
            this.btnBrand.Name = "btnBrand";
            this.btnBrand.Size = new System.Drawing.Size(128, 59);
            this.btnBrand.TabIndex = 3;
            this.btnBrand.Text = "Laporan Brand Paling Banyak Dijual";
            this.btnBrand.UseVisualStyleBackColor = true;
            this.btnBrand.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTipe
            // 
            this.btnTipe.Location = new System.Drawing.Point(464, 230);
            this.btnTipe.Margin = new System.Windows.Forms.Padding(2);
            this.btnTipe.Name = "btnTipe";
            this.btnTipe.Size = new System.Drawing.Size(128, 59);
            this.btnTipe.TabIndex = 4;
            this.btnTipe.Text = "Laporan Tipe Paling Banyak Dijual";
            this.btnTipe.UseVisualStyleBackColor = true;
            this.btnTipe.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnuser
            // 
            this.btnuser.Location = new System.Drawing.Point(464, 294);
            this.btnuser.Margin = new System.Windows.Forms.Padding(2);
            this.btnuser.Name = "btnuser";
            this.btnuser.Size = new System.Drawing.Size(128, 59);
            this.btnuser.TabIndex = 5;
            this.btnuser.Text = "Laporan User Paling Banyak Beli";
            this.btnuser.UseVisualStyleBackColor = true;
            this.btnuser.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnTtlTrans
            // 
            this.btnTtlTrans.Location = new System.Drawing.Point(464, 37);
            this.btnTtlTrans.Margin = new System.Windows.Forms.Padding(2);
            this.btnTtlTrans.Name = "btnTtlTrans";
            this.btnTtlTrans.Size = new System.Drawing.Size(128, 59);
            this.btnTtlTrans.TabIndex = 6;
            this.btnTtlTrans.Text = "Laporan Total Transaksi";
            this.btnTtlTrans.UseVisualStyleBackColor = true;
            this.btnTtlTrans.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(488, 3);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(102, 27);
            this.button6.TabIndex = 7;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // FormTransaksi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btnTtlTrans);
            this.Controls.Add(this.btnuser);
            this.Controls.Add(this.btnTipe);
            this.Controls.Add(this.btnBrand);
            this.Controls.Add(this.btnSepatu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormTransaksi";
            this.Text = "FormTransaksi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSepatu;
        private System.Windows.Forms.Button btnBrand;
        private System.Windows.Forms.Button btnTipe;
        private System.Windows.Forms.Button btnuser;
        private System.Windows.Forms.Button btnTtlTrans;
        private System.Windows.Forms.Button button6;
    }
}